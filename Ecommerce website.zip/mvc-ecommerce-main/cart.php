<!DOCTYPE html>
<html lang="en">
<title>OG Tech PC - Cart</title>
<?php include "header.php"; ?>

<div class="wide-container">
  <?php include "includes/order.inc.php" ?>
  <?php include "static/pages/cart_items.php" ?>
  <?php include "static/pages/order_items.php" ?>
</div>

<?php include "footer.php"; ?>
</html>