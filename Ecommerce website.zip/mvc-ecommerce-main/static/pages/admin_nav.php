<nav class="grey darken-4" style="margin-top: 100px; height: 100px;">
  <div class="nav wrapper">
    <a href="admin.php" class="brand-logo center white-text underline">Admin Panel</a>
    <a href="" data-target="slide-out" class="sidenav-trigger show-on-large" style="margin-top: 15px" data-activates="slide-out"><i class="material-icons">menu</i></a>
  </div>
</nav>